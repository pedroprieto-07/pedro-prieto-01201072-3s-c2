package br.com.bandtec.projetolutalivre;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoLutaLivreApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoLutaLivreApplication.class, args);
	}

}
